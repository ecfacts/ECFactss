# EC Facts — Django Website

EC Facts jaisi quiz & fact website built with Django.

---

## 🚀 Setup & Run (Step by Step)

### Step 1 — Install Python & Django
```bash
pip install django
```

### Step 2 — Project folder mein jao
```bash
cd ecfacts_django
```

### Step 3 — Database setup karo
```bash
python manage.py migrate
```

### Step 4 — Sample data load karo
```bash
python manage.py load_sample_data
```

### Step 5 — Admin user banao
```bash
python manage.py createsuperuser
# naam, email, password dalo
```

### Step 6 — Server start karo
```bash
python manage.py runserver
```

### Step 7 — Browser mein kholo
- 🏠 Website: http://127.0.0.1:8000/
- 📚 Articles: http://127.0.0.1:8000/facts/
- 🧪 Quiz: http://127.0.0.1:8000/quiz/
- ⚙️ Admin Panel: http://127.0.0.1:8000/admin/

---

## 📁 Project Structure

```
ecfacts_django/
├── manage.py
├── requirements.txt
├── ecfacts_django/
│   ├── settings.py      ← Project settings
│   └── urls.py          ← Main URL routes
└── facts/
    ├── models.py        ← Database models
    ├── views.py         ← Page logic
    ├── urls.py          ← App URL routes
    ├── admin.py         ← Admin panel config
    ├── context_processors.py
    ├── management/
    │   └── commands/
    │       └── load_sample_data.py  ← Sample data
    └── templates/
        └── facts/
            ├── base.html       ← Base layout
            ├── home.html       ← Homepage
            ├── fact_list.html  ← Articles list
            ├── fact_detail.html← Article detail
            ├── quiz.html       ← Quiz page
            └── category_detail.html
```

---

## ✏️ Naya Article Add Karna

Admin panel se: http://127.0.0.1:8000/admin/
- Facts → Add Fact
- Categories → Add Category
- Quiz Questions → Add Question

---

## 🌐 Free Mein Online Deploy Karna

### Railway.app (Easiest):
1. railway.app pe account banao
2. GitHub pe code upload karo
3. Railway se connect karo → auto deploy!

### PythonAnywhere (Free forever):
1. pythonanywhere.com pe free account
2. Files upload karo
3. WSGI configure karo

---

Made with ❤️ — EC Facts
