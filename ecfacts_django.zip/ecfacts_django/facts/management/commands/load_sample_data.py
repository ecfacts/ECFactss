from django.core.management.base import BaseCommand
from facts.models import Category, Fact, QuizQuestion


class Command(BaseCommand):
    help = 'Load sample data into the database'

    def handle(self, *args, **kwargs):
        # Create Categories
        cats = [
            {'name': 'Science', 'slug': 'science', 'icon': '⚛', 'color': '#4FC3F7'},
            {'name': 'Psychology', 'slug': 'psychology', 'icon': '🧠', 'color': '#CE93D8'},
            {'name': 'India Facts', 'slug': 'india', 'icon': '◈', 'color': '#F2D675'},
            {'name': 'Space', 'slug': 'space', 'icon': '🪐', 'color': '#80DEEA'},
            {'name': 'History', 'slug': 'history', 'icon': '📜', 'color': '#FFCC80'},
            {'name': 'Entertainment', 'slug': 'entertainment', 'icon': '🎬', 'color': '#FF8A65'},
        ]
        cat_objs = {}
        for c in cats:
            obj, _ = Category.objects.get_or_create(slug=c['slug'], defaults=c)
            cat_objs[c['slug']] = obj
            self.stdout.write(f"  ✓ Category: {c['name']}")

        # Create Sample Facts
        facts = [
            {
                'title': 'Why Does Ice Float on Water?',
                'excerpt': 'Most solids sink in their liquid form. Ice is a rare exception.',
                'body': 'When water freezes, hydrogen bonds lock into a hexagonal lattice taking up 9% more space. This makes ice less dense than liquid water, so it floats. Lakes freeze top-down, protecting aquatic life.',
                'category': cat_objs['science'],
                'hindi_summary': 'जब पानी बर्फ बनता है, हाइड्रोजन बॉन्डिंग के कारण उसका घनत्व कम हो जाता है और बर्फ पानी पर तैरती है।',
                'exam_relevance': 'Asked in UPSC Prelims, SSC CGL, Railway NTPC — Anomalous expansion of water, Hydrogen bonding.',
                'read_time': '4 min',
                'is_featured': True,
            },
            {
                'title': 'The Dunning-Kruger Effect',
                'excerpt': 'Why the least skilled are most confident — a cognitive bias that affects all of us.',
                'body': 'People with limited knowledge overestimate their abilities. To recognize your limitations, you need a base level of skill. True experts emerge with calibrated confidence.',
                'category': cat_objs['psychology'],
                'hindi_summary': 'जिन लोगों को कम ज्ञान होता है, वे खुद को विशेषज्ञ समझते हैं। असली विशेषज्ञ अपनी सीमाएं जानते हैं।',
                'exam_relevance': 'UPSC GS Paper 4 — Ethics & cognitive biases in decision-making.',
                'read_time': '5 min',
                'is_featured': True,
            },
            {
                'title': 'India Invented Zero',
                'excerpt': 'Yes, India gave the world zero — and the story is extraordinary.',
                'body': 'Brahmagupta (628 CE) wrote the first formal arithmetic rules for zero in Brahmasphutasiddhanta. The Sanskrit word "shunya" means void. Without zero, modern computing would not exist.',
                'category': cat_objs['india'],
                'hindi_summary': 'ब्रह्मगुप्त ने 628 ईस्वी में शून्य के गणितीय नियम लिखे। "शून्य" संस्कृत शब्द से आया है।',
                'exam_relevance': 'High importance: UPSC, SSC, Railway — Indian mathematical contributions.',
                'read_time': '4 min',
                'is_featured': True,
            },
            {
                'title': 'Black Holes: 6 Mind-Blowing Facts',
                'excerpt': 'Black holes are regions so dense that spacetime itself breaks.',
                'body': 'A black hole is not empty — it is extreme density. Nothing escapes, including light. Time slows near the event horizon. Spaghettification is a real scientific term for being stretched by tidal forces.',
                'category': cat_objs['space'],
                'hindi_summary': 'ब्लैक होल में गुरुत्वाकर्षण इतना शक्तिशाली होता है कि प्रकाश भी बाहर नहीं निकल सकता।',
                'exam_relevance': 'UPSC, Railway — General Science and Space technology.',
                'read_time': '5 min',
                'is_featured': False,
            },
            {
                'title': 'Ashoka: From War to Welfare',
                'excerpt': 'After Kalinga, Emperor Ashoka built the world\'s first welfare state.',
                'body': 'After the Kalinga War (261 BCE), 100,000+ were dead. Ashoka renounced war, embraced Buddhism and Dhamma — building hospitals, roads, and spreading tolerance. The Ashoka Chakra is on India\'s national flag.',
                'category': cat_objs['history'],
                'hindi_summary': 'कलिंग युद्ध के बाद सम्राट अशोक ने हिंसा त्याग दी और धम्म नीति अपनाई। अशोक चक्र भारतीय ध्वज पर है।',
                'exam_relevance': 'Extremely high for UPSC, SSC, Railway — Maurya Empire, Kalinga War, National Symbols.',
                'read_time': '5 min',
                'is_featured': True,
            },
        ]
        for f in facts:
            obj, created = Fact.objects.get_or_create(title=f['title'], defaults=f)
            if created:
                self.stdout.write(f"  ✓ Fact: {f['title']}")

        # Create Quiz Questions
        questions = [
            {
                'question': 'At what temperature does water have maximum density?',
                'option_a': '0°C', 'option_b': '4°C', 'option_c': '100°C', 'option_d': '-4°C',
                'correct_option': 'B',
                'explanation': 'Water has maximum density at 4°C. Above and below this, it expands — called anomalous expansion.',
                'category': cat_objs['science'],
            },
            {
                'question': 'Who formalized the arithmetic rules for zero?',
                'option_a': 'Aryabhata', 'option_b': 'Brahmagupta', 'option_c': 'Chanakya', 'option_d': 'Varahamihira',
                'correct_option': 'B',
                'explanation': 'Brahmagupta (628 CE) wrote the first formal arithmetic rules for zero in Brahmasphutasiddhanta.',
                'category': cat_objs['india'],
            },
            {
                'question': 'The Kalinga War was fought in which year?',
                'option_a': '321 BCE', 'option_b': '273 BCE', 'option_c': '261 BCE', 'option_d': '232 BCE',
                'correct_option': 'C',
                'explanation': 'Kalinga War was fought in 261 BCE. It transformed Ashoka from a conqueror to a welfare emperor.',
                'category': cat_objs['history'],
            },
            {
                'question': 'What is the boundary of no return around a black hole called?',
                'option_a': 'Singularity', 'option_b': 'Photon Sphere', 'option_c': 'Event Horizon', 'option_d': 'Schwarzschild Radius',
                'correct_option': 'C',
                'explanation': 'The Event Horizon is the boundary beyond which nothing — not even light — can escape a black hole.',
                'category': cat_objs['space'],
            },
            {
                'question': 'What does the Dunning-Kruger Effect describe?',
                'option_a': 'Memory loss under stress',
                'option_b': 'Low-skill people overestimating their competence',
                'option_c': 'Experts underperforming under pressure',
                'option_d': 'Fear of failure in students',
                'correct_option': 'B',
                'explanation': 'The Dunning-Kruger Effect: people with limited knowledge overestimate their abilities because they lack the skill to recognize their limitations.',
                'category': cat_objs['psychology'],
            },
        ]
        for q in questions:
            obj, created = QuizQuestion.objects.get_or_create(question=q['question'], defaults=q)
            if created:
                self.stdout.write(f"  ✓ Quiz: {q['question'][:50]}...")

        self.stdout.write(self.style.SUCCESS('\n✅ Sample data loaded successfully!'))
