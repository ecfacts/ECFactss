import random
import json
from django.shortcuts import render, get_object_or_404
from django.http import JsonResponse
from django.views.decorators.http import require_POST
from .models import Fact, Category, QuizQuestion


def home(request):
    categories = Category.objects.all()
    featured_facts = Fact.objects.filter(is_featured=True)[:6]
    latest_facts = Fact.objects.all()[:6]
    # Random fact of the day
    all_facts = list(Fact.objects.all())
    fact_of_day = random.choice(all_facts) if all_facts else None

    return render(request, 'facts/home.html', {
        'categories': categories,
        'featured_facts': featured_facts,
        'latest_facts': latest_facts,
        'fact_of_day': fact_of_day,
    })


def fact_list(request):
    category_slug = request.GET.get('category', '')
    search_query = request.GET.get('q', '')

    facts = Fact.objects.select_related('category').all()
    categories = Category.objects.all()

    if category_slug:
        facts = facts.filter(category__slug=category_slug)
    if search_query:
        facts = facts.filter(title__icontains=search_query) | facts.filter(body__icontains=search_query)

    active_category = None
    if category_slug:
        active_category = Category.objects.filter(slug=category_slug).first()

    return render(request, 'facts/fact_list.html', {
        'facts': facts,
        'categories': categories,
        'active_category': active_category,
        'search_query': search_query,
    })


def fact_detail(request, pk):
    fact = get_object_or_404(Fact, pk=pk)
    related = Fact.objects.filter(category=fact.category).exclude(pk=pk)[:3]
    return render(request, 'facts/fact_detail.html', {
        'fact': fact,
        'related': related,
    })


def quiz(request):
    questions = list(QuizQuestion.objects.select_related('category').all())
    random.shuffle(questions)
    questions = questions[:8]  # 8 questions per quiz

    quiz_data = []
    for q in questions:
        quiz_data.append({
            'id': q.id,
            'question': q.question,
            'options': [q.option_a, q.option_b, q.option_c, q.option_d],
            'correct': ord(q.correct_option) - ord('A'),
            'explanation': q.explanation,
            'category': q.category.name,
        })

    return render(request, 'facts/quiz.html', {
        'quiz_data_json': json.dumps(quiz_data),
    })


def category_detail(request, slug):
    category = get_object_or_404(Category, slug=slug)
    facts = Fact.objects.filter(category=category)
    return render(request, 'facts/category_detail.html', {
        'category': category,
        'facts': facts,
    })


def random_fact_api(request):
    facts = list(Fact.objects.values('id', 'title', 'excerpt'))
    if facts:
        fact = random.choice(facts)
        return JsonResponse(fact)
    return JsonResponse({'error': 'No facts found'}, status=404)
