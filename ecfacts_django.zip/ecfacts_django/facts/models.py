from django.db import models


class Category(models.Model):
    name = models.CharField(max_length=100)
    slug = models.SlugField(unique=True)
    icon = models.CharField(max_length=10, default='◈')
    color = models.CharField(max_length=20, default='#F2D675')

    def __str__(self):
        return self.name

    class Meta:
        verbose_name_plural = 'Categories'


class Fact(models.Model):
    title = models.CharField(max_length=255)
    excerpt = models.TextField()
    body = models.TextField()
    category = models.ForeignKey(Category, on_delete=models.CASCADE, related_name='facts')
    hindi_summary = models.TextField(blank=True)
    exam_relevance = models.TextField(blank=True)
    read_time = models.CharField(max_length=20, default='3 min')
    created_at = models.DateTimeField(auto_now_add=True)
    is_featured = models.BooleanField(default=False)

    def __str__(self):
        return self.title

    class Meta:
        ordering = ['-created_at']


class QuizQuestion(models.Model):
    question = models.TextField()
    option_a = models.CharField(max_length=255)
    option_b = models.CharField(max_length=255)
    option_c = models.CharField(max_length=255)
    option_d = models.CharField(max_length=255)
    correct_option = models.CharField(max_length=1, choices=[
        ('A', 'A'), ('B', 'B'), ('C', 'C'), ('D', 'D')
    ])
    explanation = models.TextField()
    category = models.ForeignKey(Category, on_delete=models.CASCADE, related_name='quiz_questions')

    def __str__(self):
        return self.question[:80]
