from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('facts/', views.fact_list, name='fact_list'),
    path('facts/<int:pk>/', views.fact_detail, name='fact_detail'),
    path('quiz/', views.quiz, name='quiz'),
    path('category/<slug:slug>/', views.category_detail, name='category_detail'),
    path('api/random-fact/', views.random_fact_api, name='random_fact_api'),
]
